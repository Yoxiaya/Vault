# vault-cryption

面向 Expo 55 和 Web 的 KEK / DEK 密码库加密示例库。使用 Argon2id 从主密码派生 KEK，
使用随机 DEK 和 AES-256-GCM 加密密码库记录。

AES-GCM 和安全随机数由 Expo 55 的 `expo-crypto` 提供；UTF-8 与 Base64 编解码不依赖 `TextEncoder`、`atob` 或 `btoa` 等运行时全局变量。

> 当前默认 Argon2id 参数仅用于演示。投入生产前必须在目标设备上完成性能与安全评估。

## 加密原理

本库采用 KEK / DEK 两层密钥结构：

- **主密码（Master Password）**：由用户输入，不保存、不上传。
- **KEK（Key Encryption Key）**：使用 Argon2id 从主密码和随机 Salt 派生，仅用于加密 DEK。
- **DEK（Data Encryption Key）**：随机生成的 256 位密钥，真正用于加密密码库中的记录。

整体关系如下：

```mermaid
flowchart TD
  subgraph Create["创建密码库"]
    Password["用户主密码"]
    Salt["随机 KDF Salt<br/>16 字节"]
    KDF["Argon2id<br/>内存困难型密钥派生"]
    KEK["KEK<br/>32 字节"]
    RandomDEK["安全随机数生成器"]
    DEK["DEK<br/>32 字节"]
    Wrap["AES-256-GCM<br/>使用 KEK 加密 DEK"]
    WrappedDEK["wrappedDEK + Wrap IV"]

    Password --> KDF
    Salt --> KDF
    KDF --> KEK
    RandomDEK --> DEK
    KEK --> Wrap
    DEK --> Wrap
    Wrap --> WrappedDEK
  end

  subgraph Store["可持久化或上传服务端"]
    Metadata["VaultMetadata<br/>Salt、KDF 参数、Wrap IV、wrappedDEK"]
    EncryptedRecord["EncryptedRecord<br/>Record IV、密文、GCM Tag"]
  end

  subgraph RecordEncryption["加密记录"]
    Data["业务数据"]
    Encode["JSON 序列化 + UTF-8 编码"]
    Encrypt["AES-256-GCM<br/>每条记录使用随机 IV"]

    Data --> Encode
    Encode --> Encrypt
    DEK --> Encrypt
    Encrypt --> EncryptedRecord
  end

  Salt --> Metadata
  WrappedDEK --> Metadata

  subgraph Unlock["重新解锁"]
    InputPassword["用户再次输入主密码"]
    DeriveAgain["使用元数据中的 Salt 和参数<br/>再次执行 Argon2id"]
    RestoredKEK["重新派生 KEK"]
    Unwrap["AES-256-GCM<br/>解密 wrappedDEK"]
    SessionDEK["恢复 DEK<br/>仅保留在会话内存"]

    InputPassword --> DeriveAgain
    Metadata --> DeriveAgain
    DeriveAgain --> RestoredKEK
    RestoredKEK --> Unwrap
    Metadata --> Unwrap
    Unwrap -->|"密码和认证标签正确"| SessionDEK
    Unwrap -->|"密码错误或数据被篡改"| Failure["解锁失败"]
  end

  SessionDEK --> Decrypt["AES-256-GCM 解密记录"]
  EncryptedRecord --> Decrypt
  Decrypt --> Plaintext["解密后的业务数据"]
```

### 创建密码库

调用 `createVault(masterPassword)` 时：

1. 生成一个随机的 16 字节 KDF Salt。
2. 使用 Argon2id 对“主密码 + Salt”执行内存困难型密钥派生，得到 32 字节 KEK。
3. 使用密码学安全随机数生成一个 32 字节 DEK。
4. 使用 KEK 和 AES-256-GCM 加密 DEK，得到 `wrappedDEK`。
5. 返回可持久化的 `metadata` 和只应保留在内存中的明文 `dek`。

Salt 不需要保密，它的作用是让相同主密码产生不同的 KEK，并降低预计算和彩虹表攻击的收益。KEK 不会写入元数据；应用关闭或会话锁定后，需要再次输入主密码才能重新派生。

### 解锁密码库

调用 `unlockVault(masterPassword, metadata)` 时：

1. 从元数据读取原始 Salt 和 Argon2id 参数。
2. 使用用户输入的主密码重新派生 KEK。
3. 使用 KEK 解密 `wrappedDEK`。
4. 如果主密码错误、元数据被篡改或认证标签无效，AES-GCM 解密会失败，不会返回 DEK。

### 加密记录

调用 `encryptRecord(dek, data)` 时，数据先经过 JSON 序列化和 UTF-8 编码，再使用 DEK 与 AES-256-GCM 加密。每次加密都会生成新的随机 12 字节 IV，因此相同内容多次加密也会得到不同密文。

AES-GCM 属于认证加密算法。它不仅隐藏明文，还通过 16 字节 Authentication Tag 检测密文、IV 或相关数据是否被修改。本库将 Tag 附加在密文末尾共同保存。

### 为什么不直接用主密码加密每条记录

两层密钥结构把用户密码与业务数据分离：

- Argon2id 这种成本较高的密码派生只需在创建或解锁时执行一次。
- 解锁后可以用随机 DEK 高效加密多条记录。
- 主密码不直接参与每条记录的加密，也不需要保存在内存中持续使用。
- 设计上更容易实现仅重新包装 DEK 的主密码更换流程，而不必重新加密全部记录；当前库尚未提供该流程的公开 API。

### 安全边界

该方案主要保护服务端数据库、备份或本地密文泄露后的数据。攻击者拿到 `VaultMetadata` 和 `EncryptedRecord` 后，仍需要猜测主密码，并为每次猜测执行 Argon2id。

它不能防御已经控制客户端运行环境的攻击者。例如 XSS、恶意依赖、被攻陷的设备、键盘记录器或调试注入仍可能读取用户输入、明文 DEK 或解密后的记录。因此客户端代码完整性、依赖安全、会话锁定和强主密码同样重要。

## 安装

```bash
npm install vault-cryption
npx expo install expo-crypto
```

要求使用 Expo SDK 55。`expo-crypto` 支持 Android、iOS、tvOS 和 Web，并且包含在 Expo Go 中；不需要安装 `react-native-quick-crypto`，也不需要设置 `global.crypto`。

## Expo 55 使用

```ts
import {
  createVault,
  decryptRecord,
  encryptRecord,
  rewrapVaultKey,
  unlockVault,
} from "vault-cryption";

// 注册并初始化密码库
const { metadata, dek } = await createVault(masterPassword);

// metadata 可 JSON 序列化，应上传服务端保存；dek 只能留在当前会话内存中。
await saveVaultMetadata(metadata);

// 保存记录
const encryptedRecord = await encryptRecord(dek, {
  account: "alice@example.com",
  password: "secret",
});
await saveEncryptedRecord(encryptedRecord);

// 新会话中，从服务端取回 metadata，使用其记录的旧版本参数解锁。
const unlockedDek = await unlockVault(masterPassword, metadata);
const record = await decryptRecord<{ account: string; password: string }>(
  unlockedDek,
  encryptedRecord,
);
```

### Change the master password

Rewrap the existing DEK with the new master password, then atomically save the returned complete metadata object. Account records do not need to be encrypted again.

```ts
const updatedMetadata = await rewrapVaultKey(dek, newMasterPassword);
await updateWrappedKey(updatedMetadata);
```

`rewrapVaultKey` always generates a new salt and wrapping IV. It does not generate or replace the DEK.

Expo Metro 会通过包的 `react-native` 导出条件自动选择 Expo 实现。如果项目自定义了 Metro，并且没有启用 package exports，可以显式从 Expo 入口导入：

```ts
import {
  createVault,
  decryptRecord,
  encryptRecord,
  unlockVault,
} from "vault-cryption/expo";
```

所有加解密 API 都是异步的，建议在界面中显示处理中状态，并防止用户重复提交。

## 与原浏览器版本的数据兼容性

存储结构没有改变：

- AES 算法仍然是 AES-256-GCM。
- IV 长度仍然是 12 字节。
- GCM Authentication Tag 长度仍然是 16 字节。
- `ciphertext` 仍然保存为“密文 + 末尾 16 字节 Tag”的 Base64 字符串。
- `VaultMetadata` 和 `EncryptedRecord` 的 JSON 字段没有变化。

因此，旧版通过 Web Crypto 产生的数据可以直接由 Expo 55 版本解密，无需执行数据库迁移。升级前仍建议用真实旧数据完成 Android、iOS 和 Web 交叉解密测试，并保留备份。

## Argon2id 性能

Argon2id 当前由 `@noble/hashes` 的 JavaScript 实现执行。它可以在 Expo/Hermes 中运行，但提高内存参数后可能阻塞 JavaScript 线程，并在中低端 Android 设备上产生明显卡顿。

当前默认基线为 `{ t: 2, m: 19456, p: 1, dkLen: 32 }`。正式发布前仍必须在目标最低配置 Android 真机、iPhone 真机和 Web 设备上测试耗时、峰值内存与界面响应。实际参数会保存在 `VaultMetadata.kdfParams` 中，解锁旧密码库时始终使用元数据内保存的参数。

## 数据保存边界

- 服务端保存 `VaultMetadata` 和 `EncryptedRecord`。
- 不要保存或上传主密码、KEK、明文 DEK 和解密后的记录。
- 不要把 DEK 放入 AsyncStorage、SecureStore、SQLite、文件、URL、分析事件或日志。
- App 进入锁定状态、用户退出登录或会话结束后，应丢弃 DEK，并要求重新解锁。
- `expo-secure-store` 可以保存设备凭据或短期令牌，但不应在不改变威胁模型的情况下自动持久化明文 DEK。

## 发布

发布前先把 `package.json` 中的包名改为你拥有的 npm 包名，然后执行：

```bash
npm run typecheck
npm run build
npm pack --dry-run
npm login
npm publish --access public
```

## 浏览器验证

项目使用 Vite 启动本地验证页，页面会执行创建密码库、加密记录、重新解锁和解密的完整流程：

```bash
npm install
npm run dev
```

打开终端显示的 localhost 地址，填写测试数据后点击“运行完整验证”。验证页直接引用 `src` 源码；npm 包仍由 `npm run build` 使用 tsup 构建。
